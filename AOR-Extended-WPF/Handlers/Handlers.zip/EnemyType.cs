﻿namespace AOR_Extended_WPF.Handlers
{
    public enum EnemyType
    {
        LivingHarvestable = 0,
        LivingSkinnable = 1,
        Enemy = 2,
        MediumEnemy = 3,
        EnchantedEnemy = 4,
        MiniBoss = 5,
        Boss = 6,
        Drone = 7,
        MistBoss = 8,
        Events = 9
    }
}