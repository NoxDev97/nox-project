﻿namespace AOR_Extended_WPF.Handlers
{
    public enum DungeonType
    {
        Solo = 0,
        Group = 1,
        Corrupted = 2,
        Hellgate = 3
    }
}
